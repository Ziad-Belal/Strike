import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Header from './components/Header.jsx'
import Footer from './components/Footer.jsx'
import Home from './pages/Home.jsx'
import Category from './pages/Category.jsx'
import ProductPage from './pages/ProductPage.jsx'

export default function App() {
  const [cartOpen, setCartOpen] = React.useState(false)
  const [cartItems, setCartItems] = React.useState([])

  const addToCart = (product, size, qty) => {
    if (!size) return alert('Please select a size first.')
    setCartItems((prev) => [...prev, { ...product, size, qty }])
    setCartOpen(true)
  }

  const removeItem = (idx) => setCartItems((prev) => prev.filter((_, i) => i !== idx))

  const CartDrawer = React.lazy(() => import('./components/CartDrawer.jsx'))

  return (
    <div className='min-h-screen bg-white text-black'>
      <Header cartCount={cartItems.length} onOpenCart={() => setCartOpen(true)} />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/men' element={<Category category='men' />} />
        <Route path='/women' element={<Category category='women' />} />
        <Route path='/kids' element={<Category category='kids' />} />
        <Route path='/sale' element={<Category category='sale' />} />
        <Route path='/product/:slug' element={<ProductPage addToCart={addToCart} />} />
        <Route path='*' element={<div className='container py-10'>Page not found.</div>} />
      </Routes>
      <Footer />
      <React.Suspense fallback={null}>
        <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} items={cartItems} removeItem={removeItem} />
      </React.Suspense>
    </div>
  )
}
